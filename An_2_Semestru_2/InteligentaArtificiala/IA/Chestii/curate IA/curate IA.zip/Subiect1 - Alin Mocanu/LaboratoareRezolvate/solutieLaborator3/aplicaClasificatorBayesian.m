function gstar = aplicaClasificatorBayesian(X,c)

gstar = X > c;