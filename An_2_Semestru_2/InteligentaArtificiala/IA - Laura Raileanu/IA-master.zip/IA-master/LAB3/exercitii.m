%SCRIPT MNIST
%x = 1:10; y = 11:20; save('x.mat', 'x'); save('x.mat', 'x', 'y'); clear; load('x.mat');
