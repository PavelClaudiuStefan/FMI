% Exercitii laboratorul 5 %
% RETEA NEURONALA SI alte chestii %
