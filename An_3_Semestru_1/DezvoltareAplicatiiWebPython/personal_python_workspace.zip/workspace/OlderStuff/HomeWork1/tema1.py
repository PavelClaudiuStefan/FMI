#!/usr/bin/python
# -*- coding: utf-8 -*-


# 1. În fișierul "ids.txt" se află CNP-uri, fiecare CNP ocupând o
# linie a fișierului. Scrieți o funcție Python care citește fiecare CNP
# din fișier, scrie la sfârșitul fișierului o linie cu 10 simboluri '#', iar
# apoi, pe fiecare linie, CNP-urile corecte din fișier.

# Prima cifră a CNP-ului trebuie să fie cuprinsă între 1 şi 5
# Următoarele 6 cifre reprezintă data naşterii în formatul yymmdd
# După data naşterii urmează încă 6 cifre 

def is_cnp_correct(cnp):
    if len(cnp) != 13:
        return False

    if int(cnp[0]) < 1 or int(cnp[0]) > 5:
        return False

    mm = int(cnp[3:5])
    if mm < 1 or mm > 12:
        return False

    dd = int(cnp[5:7])
    if dd < 1 or dd > 31:
        return False

    return True
 
 
def correct_ids():
    list =[]
    with open('ids.txt', 'r') as ids:
        for cnp in ids.read().splitlines():
            if is_cnp_correct(cnp):
                list.append(cnp)
                
    with open('ids.txt', 'a') as ids:
        ids.write('\n##########')
        for cnp in list:
            ids.write('\n' + cnp)
#correct_ids()


# 2. Să se scrie o funcție Python care primește un număr variabil de argumente
# și care returnează un dicționar format din numerele prime și numerele
# perfecte* primite ca parametri. Se pot folosi funcții auxiliare.
# *Un număr se numește perfect dacă suma divizorilor săi proprii, fără numărul
# în sine, este egală cu acesta (6=1+2+3)
#  Ex: Pentru datele de intrare 3, 4, 15, 7, 6, 2, 28, 13, 8
#      output-ul va fi de forma
#         {
#             'prime': [3, 7, 2, 13],
#             'perfect': [6, 28]
#         }

def is_prime(num):
    for divisor in range(2, num):
        if num % divisor == 0:
            return False
    return True


def is_perfect(num):
    sum = 0
    for divisor in range(1, num):
        if not num % divisor:
            sum += divisor
    if num == sum:
        return True
    return False


def prime_perfect(*args):
    prime_numbers = []
    perfect_numbers = []
    for x in args:
        if is_prime(x):
            prime_numbers.append(x)
        if is_perfect(x):
            perfect_numbers.append(x)
            
    return {'prime': prime_numbers, 'perfect': perfect_numbers}


# 3. Să se scrie o funcție Python care primește ca parametru o propoziție.
# Funcția va returna propoziția în care cuvintele de pe poziții pare vor avea
# literele în ordine inversă, iar cuvintele de pe poziții impare vor fi
# eliminate.

def reverse(word):
    return word[::-1]


def odd_sentence(sentence):
    new_sentence_words = []
    words = sentence.split(' ')
    for i in xrange(len(words)):
        if i % 2 == 0:
            new_sentence_words.append(reverse(words[i]))
            
    return ' '.join(new_sentence_words)


# 4. În fișierul "words.txt" se află pe fiecare linie câte un cuvânt. Scrieți un
# program care:
#     a) alege aleator un cuvânt din fișier
#     b) face o permutare aleatoare a acestui cuvânt
#     c) afișează pentru utilizator acea permutare (anagramă)
#     d) îi oferă utilizatorului 3 șanse să ghicească cuvântul original

# Găsiţi informaţii despre modulul random în secţiunea Suport de curs--> Operaţii de bază
import random

def random_word():
    words = []
    with open('/home/ubuntu/workspace/HomeWork1/words.txt', 'r') as words_file:
        for word in words_file.read().splitlines():
            words.append(word)
    i = random.randint(0, len(words)-1)
    return words[i]


def shuffle_word(word):
    list_word = list(word)
    random.shuffle(list_word)
    return ''.join(list_word)


def guess(word):
    for i in xrange(3):
        guessed_word = raw_input("Guess: ")
        if word == guessed_word:
            print ('Correct')
            break
        else:
            print ('Wrong')


def guess_anagram():
    rand_word = random_word()
    shuffled_word = shuffle_word(rand_word)
    print shuffled_word
    guess(rand_word)


# 5. Scrieți o funcție care să returneze o listă cu datele tuturor zilelor de
# miercuri ale unei luni date ca parametru (ca întreg). Se consideră că luna
# dată ca parametru este din anul curent. Datele vor fi returnate ca string-uri
# în formatul yyyy-mm-dd.
from datetime import datetime, timedelta
def get_wednesdays(mm):
    wednesdays = []
    
    #Current year
    #yyyy = datetime.today().year
    
    #Year used in testing
    yyyy = 2016
    
    date1 = datetime(year=yyyy, month=mm, day=1)
    date2 = datetime(year=yyyy, month=mm+1, day=1)
    while date1 < date2:
        if date1.isoweekday() == 3:
            wednesdays.append(date1.date().isoformat())
        date1 += timedelta(1)
        
    return wednesdays


# Funcție care compară rezultatele obținute în urma apelării unei funcții cu
# cele așteptate (corecte).
def test(got, expected):
    if got == expected:
        prefix = ' OK '
    else:
        prefix = '  X '
    print '{0} got: {1}, expected: {2}'.format(prefix, got, expected)


# Funcția de mai jos testează rezultatele funcțiilor din exerciții
def main():
    print '1. CNP-uri corecte'
    print 'Fără teste \n'

    print '2. Numere prime sau perfecte'
    test(prime_perfect(3, 4, 15, 7, 6, 2, 28, 13, 8),
         {'prime': [3, 7, 2, 13], 'perfect': [6, 28]})
    test(prime_perfect(3, 4, 15, 7, 2, 13),
         {'prime': [3, 7, 2, 13], 'perfect': []})
    print

    print '3. Propoziție modificată'
    test(odd_sentence('The weather is cold'), 'ehT si')
    test(odd_sentence('Hello'), 'olleH')
    print

    print '4. Ghicire anagramă'
    print 'Fără teste \n'

    print '5. Ziua de miercuri'
    test(get_wednesdays(10),
         ['2016-10-05', '2016-10-12', '2016-10-19', '2016-10-26'])

if __name__ == '__main__':
    main()
    print '\n\n\n'
    #guess_anagram()
