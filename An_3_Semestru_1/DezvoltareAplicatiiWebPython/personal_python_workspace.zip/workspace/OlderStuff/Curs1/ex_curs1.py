def ex1():
    for x in xrange(0, 100):
        print('Hello world')
        
def ex2():
    hellos = ''
    for x in xrange(1, 100):
        hellos += 'hello '
    print('Hmm, ' + hellos + 'bro!')
    
def ex3():
    a = [1, 3, 20, 1024, 53, 12, 102, 1, 4, 43, 32]
    for num in a:
        if num % 3 == 0:
            print('Numarul {} este divizibil cu 3'.format(num))
        else:
            print('Numarul {} nu este divizibil cu 3'.format(num))

def ex4():
    a = [1, 3, 20, 1024, 53, 12, 102, 1, 4, 43, 32]
    a2 = []
    for x in xrange(1, len(a), 2):
        a2.append(a[x])
    print(a2)
    
def ex5():
    def fizzbuzz(num):
        result = ''
        if num % 3 == 0:
            result += 'fizz'
        if num % 5 == 0:
            result += 'buzz'
        if num % 3 != 0 and num % 5 != 0:
            result = num
        return result
    print ([fizzbuzz(x) for x in range(1, 101)])
    
def ex6():
    class Product:
        def __init__(self, name, price):
            self.name = name
            self.price = price
        def price_tva(self):
            return (self.price + self.price * 0.19)
            
        def print_price(self):
            print(self.name + ' ' + str(self.price_tva()))
            
    tastatura = Product('tastatura', 70)
    tastatura.print_price()
    mouse = Product('mouse', 50)
    mouse.print_price()
    casti = Product('casti', 100)
    casti.print_price()
    
    print('Pret total: ' + str(tastatura.price_tva() + mouse.price_tva() + casti.price_tva()))
    
    
def ex7(n):
    factorial = 1
    for x in xrange(2, n+1):
        factorial *= x
    print(factorial)
    
def ex8():
    for x in xrange(2000, 3001):
        if x % 5 == 0 and x % 7 != 0:
            print(str(x) + ', '),
    
def ex9(word):
    is_palindrome = True
    for x in xrange(0, (len(word) / 2) + 1):
        if word[x] != word[len(word)-1 - x]:
            is_palindrome = False
            
    if is_palindrome:
        print(word + ' is a palindrom')
    else:
        print(word + ' is not a palindrom')
    
def ex10(a, b):
    has_common_element = False
    for x in a:
        for y in b:
            if x == y:
                has_common_element = True
    if has_common_element:
        print('True')
    else:
        print('False')
    
def ex11(words):
    def find_longest_word(words):
        max_length = 0
        for word in words:
            if max_length < len(word):
                max_length = len(word)
        return max_length
    print(find_longest_word(words))
    
def ex12(words, n):
    def filter_long_words(words, n):
        n_words = []
        for word in words:
            if len(word) > n:
                n_words.append(word)
        return n_words
    print(filter_long_words(words, n))
        
    
def ex13():
    def f(*numbers):
        sum = 0
        for number in numbers:
            sum += number
        return sum
    print(f(1, 2, 3, 4))
    
def ex14():
    def encrypt(message):
        result = ""
        for x in xrange(0, len(message)):
            if ord(message[x]) >= 97 and ord(message[x]) <= 122:
                result += chr(ord(message[x]) + 1)
            else:
                result += message[x]
        return result
    
    def decrypt(message):
        result = ""
        for x in xrange(0, len(message)):
            if ord(message[x]) >= 97 and ord(message[x]) <= 122:
                result += chr(ord(message[x]) - 1)
            else:
                result += message[x]
        return result
    print(decrypt("bob bsf nfsf, ebs pbsf tj qfsf"))
    print(encrypt("ana are mere, dar oare si pere"))
    
if __name__ == '__main__':
    print('Loaded')
    x = raw_input('scrie: ')
    print(x)