from datetime import date, datetime, timedelta, time

################################################################################

def ex1():
    with open("input.txt", "r") as input_file:
        numar_linii = 0
        for line in input_file:
            numar_linii += 1
    with open("output.txt", "w") as output_file:
        output_file.write(str(numar_linii))
        print numar_linii

################################################################################
    
def ex2():
    with open('input.txt', 'r') as input_file:
        for line in input_file:
            year, month, day = [int(x) for x in line.split()]
            birthday = date(year, month, day)
            number_of_days = date.today() - birthday
            print number_of_days

################################################################################

def ex3():
    x = int(raw_input("Numar: "))
    list_of_squares = [x**2 for x in range(x+1)]
    print sum(list_of_squares)
    
################################################################################

def ex4(dumb):
    year = datetime.now().year
    month_us = datetime.now().strftime('%B')
    day = datetime.now().day
    hour = datetime.now().hour
    minute = datetime.now().minute
    if dumb is 'america' or dumb is 'USA' or dumb is 'US':
        print('{} {}, {} - {}:{}'.format(month_us, day, year, hour, minute))

################################################################################

def ex5():      
    print [(x, y) for x in range(1, 7) for y in range(1, 7)]

################################################################################

def ex6(list):
    #print {x for x in list}
    new_list = []
    for x in list:
        if x not in new_list:
            new_list.append(x)
    print(new_list)
    
################################################################################

def ex7():
    companies = [
        ("Pixar", 2),
        ("Disney", 4),
        ("Warner Bros.", 9),
        ("Universal", 5),
        ("Reception", 0),
        ("Studio Ghibli", 8),
        ("DreamWorks", 6)
    ]
    companies_dict = {value:key for key, value in companies}
    print companies_dict

################################################################################

def ex8():
    companies = [
        ("Pixar", 2),
        ("Disney", 4),
        ("Warner Bros.", 9),
        ("Universal", 5),
        ("Reception", 0),
        ("Studio Ghibli", 8),
        ("DreamWorks", 6)
    ]
    companies_dict = {key:value for value, key in companies}
    list_of_companies = [companies_dict.get(i, None)for i in range(11)]
    print list_of_companies

################################################################################

def add_person(db, id, name, age):
    db[id] = {'name': name, 'age': age}
    
def querry_underage(db):
    return [line['name'] for line in db.values() if line['age'] < 18]

def set_python(db, id, knows_python):
    pers_dict =  db.get(id, None)
    if pers_dict is not None:
        pers_dict['python'] = knows_python
        print (pers_dict)
    else:
        print('Persoana cu id-ul {} nu exista'.format(id))
    

def ex9():
    database = {}
    add_person(database, 0, 'Claudiu', 21)
    add_person(database, 1, 'Alin', 15)
    add_person(database, 2, 'Alex', 17)
    
    print(querry_underage(database))
    set_python(database, 0, True)
    set_python(database, 3, False)
    
################################################################################

if __name__ == '__main__':
    ex9()