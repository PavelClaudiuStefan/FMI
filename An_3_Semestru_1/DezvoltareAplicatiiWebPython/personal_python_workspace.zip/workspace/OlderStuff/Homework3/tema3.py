import json, requests, csv
from bs4 import BeautifulSoup
from unidecode import unidecode

import calendar

################################################################################

# Ex 1

# Metoda cu descarcare csv
def total_valori_contracte():
    dict_judet = dict()
    
    with open('anunturi-participare-2015.csv', 'rb') as csvfile:
        my_reader = csv.reader(csvfile, delimiter=',')
        firstline_not_read = True
        for row in my_reader:
            if firstline_not_read:
                firstline_not_read = False
                continue
            judet = row[5]
            valoare = row[10]
            valoare = float(valoare.replace(",", ""))
            currency = row[11]
            if currency != 'RON':
                valoare = currency_to_ron(valoare, currency)
            dict_judet[judet] = dict_judet.get(judet, 0) + valoare

    return dict_judet

# Metoda directa
def total_valori_contracte_parsed():
    url = 'http://data.gov.ro/api/3/action/datastore_search'

    params = {
        "resource_id":"9e0f19f1-b4ce-4f27-b5ec-6f644145e7f3",
        "limit":10000
    }
    
    resp = requests.get(url=url, params=params)
    data = json.loads(resp.text)
    
    dict_judet = dict()
    
    for record in data['result']['records']:
        judet = record['Judet']
        valoare = float(record['Valoare Estimata'])
        currency = record['Moneda']
        if currency != 'RON':
            valoare = currency_to_ron(valoare, currency)
        dict_judet[judet] = dict_judet.get(judet, 0) + valoare

    return dict_judet
    
################################################################################

# Ex 2
def dict_to_csv(my_dict):
    with open('valori_contracte_pe_judet.csv', 'wb') as csvfile:
        my_writer = csv.writer(csvfile, delimiter=',')
        my_writer.writerow(['Judet', 'Valoare Estimata'])
        for x,y in my_dict.items():
            my_writer.writerow([x, y])

################################################################################

# Ex 3
def export_json():
    
    url = 'http://data.gov.ro/api/3/action/datastore_search'
    params = {
        "resource_id":"9e0f19f1-b4ce-4f27-b5ec-6f644145e7f3",
        "limit":10000
    }
    resp = requests.get(url=url, params=params)
    data = json.loads(resp.text)
    
    dict_contracte = dict()
    for record in data['result']['records']:
        luna = calendar.month_name[int(record['Data Publicare'][5:7])]
        valoare = float(record['Valoare Estimata'])
        currency = record['Moneda']
        if currency != 'RON':
            valoare = currency_to_ron(valoare, currency)
        dict_contracte[luna] = dict_contracte.get(luna, 0) + valoare

    with open('valori_contracte_pe_luna.txt', 'w') as output:
        json.dump(dict_contracte, output)

################################################################################

# Ex 4
def currency_to_ron(amount, currency):
    url = 'http://www.bnr.ro/nbrfxrates.xml'
    req = requests.get(url)
    soup = BeautifulSoup(req.text, 'xml')
    
    rate = 0
    for r in soup.findAll('Rate'):
        if r.attrs['currency'] == currency:
            rate =  float(r.text)
    
    if rate != 0:
        return amount / rate
    else:
        return None

################################################################################

# Ex 6
def populatie_judet():
    url = 'https://ro.wikipedia.org/wiki/Lista_jude%C8%9Belor_Rom%C3%A2niei_dup%C4%83_popula%C8%9Bie'
    
    resp = requests.get(url)
    soup = BeautifulSoup(resp.text, 'html.parser')
    
    table = soup.find("table", { "class" : "wikitable sortable" })
    
    my_dict = dict()
    
    for row in table.findAll("tr"):
        cells = row.findAll("td")
        if len(cells) == 10 and cells[0].text != '':
            if cells[0].text == '1':
                judet = unidecode(cells[1].find('a').text).replace("Municipiul ", "")
            else:
                judet = unidecode(cells[1].find('a').text)
            cells[9].find('span').extract()
            populatie = float(cells[9].text.replace(".", ""))
            my_dict[judet] = populatie
    
    return my_dict

################################################################################

# Ex 7
def agregare():
    dict_agregat = dict()
    dict_contracte = total_valori_contracte()
    dict_populatie = populatie_judet()
    
    for judet,valoare in dict_contracte.items():
        dict_agregat[judet] = valoare / dict_populatie.get(judet, valoare)
    
    return dict_agregat

################################################################################

if __name__ == '__main__':
    contracte_dict = total_valori_contracte()
    #contracte_dict1 = total_valori_contracte_parsed
    dict_to_csv(contracte_dict)
    
    export_json()
    
    #for x,y in populatie_judet().items():
        #print x,y
    
    #populatie_dict = populatie_judet()
    print populatie_judet()
    
    # for k,v in agregare().items():
    #   print(k + ' -> ' + str(v))
    