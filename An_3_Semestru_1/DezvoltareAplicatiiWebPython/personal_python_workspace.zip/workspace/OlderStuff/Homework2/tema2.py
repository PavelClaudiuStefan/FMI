
# coding=utf-8
"""
Ex. 1
Definiți clasa DateRange care primește la inițializare o valoare start și o
valoare end, ambele fiind obiecte datetime.date.
Adăugați proprietatea:
    - days - returnează numărul de zile din intervalul [start, end]
Adăugați metoda:
    - contains - primește un obiect date și returnează True dacă data se
                  află în intervalul [start, end].
"""

from datetime import timedelta

class DateRange(object):
    def __init__(self, start, end):
        self.start = start
        self.end = end
        self.set_days((end - start).days)

    def set_days(self, days):
        self.__days = days

    def get_days(self):
        return self.__days

    days = property(get_days, set_days)

    def contains(self, obj):
        if obj >= self.start and obj <= self.end:
            return True
        else:
            return False

"""
Ex. 2
Definiți clasa Car cu atributele: brand, model, daily_price.
 Adăugați metoda:
    - get_rental_price(period) - returnează prețul de închiriere pentru
    perioada respectivă.
Permiteți afișarea informațiilor despre mașină în formatul:
    "Acesta este un brand model și prețul la închiriere este daily_price"
"""


class Car(object):

    def __init__(self, brand, model, daily_price):
        self.brand = brand
        self.model = model
        self.daily_price = daily_price

    def get_rental_price(self, period):
        return self.daily_price * period.days

    def __str__(self):
        return "Acesta este un {} {} si pretul la inchiriere este {}".format(self.brand, self.model,self.daily_price)


"""
Ex. 3
Definiți clasa Limousine care extinde clasa Car, și are în plus următoarele
atribute: driver_salary. La prețul de închiriere va adăuga salariul șoferului.
"""


class Limousine(Car):
    def __init__(self, brand, model, daily_price, driver_salary):
        super(Limousine, self).__init__(brand, model, daily_price)
        self.driver_salary = driver_salary
    
    def get_rental_price(self, period):
        return self.daily_price * period.days + self.driver_salary

"""
Ex. 4
Definiți clasa Person cu atributele: first_name, last_name și birthday.
"""


class Person(object):
    def __init__(self, first_name, last_name, birthday):
        self.first_name = first_name
        self.last_name = last_name
        self.birthday = birthday

"""
Ex. 5
Definiți clasa CarRental cu atributele: cars. Scrieți metodele:
    - add_car(car) - adaugă o mașină în centrul de închirieri
    - get_cars - returnează o listă cu mașinile filtrate după brand și preț
    maxim.
    - get_price(customer, car, period) - returnează prețul final al tranzacției.
      Dacă ziua de naștere a clientului este în intervalul închirierii, se
      aplică o reducere de 10%.

"""

from datetime import date
class CarRental(object):
    def __init__(self):
        self.cars = []

    def add_car(self, car):
        self.cars.append(car)

    # Varianta 1
    # def get_cars(self, brand=None, max_price=None):
    #     wanted_cars = []
    #     if brand is not None:
    #         if max_price is not None:
    #             for car in self.cars:
    #                 if car.brand == brand and car.daily_price <= max_price:
    #                     wanted_cars.append(car)
    #         else:
    #             for car in self.cars:
    #                 if car.brand == brand:
    #                     wanted_cars.append(car)
    #     else:
    #         if max_price is not None:
    #             for car in self.cars:
    #                 if car.daily_price <= max_price:
    #                     wanted_cars.append(car)
    #         else:
    #             wanted_cars = self.cars
    #     return wanted_cars
    
    # Varianta 2.0
    def get_cars(self, brand=None, max_price=None):
        return [car for car in self.cars if is_wanted(car, brand, max_price)]

    def get_price(self, customer, car, period):
        custom_birthday = customer.birthday.replace(year=period.start.year)
        if period.start <= custom_birthday and custom_birthday <= period.end:
            return (car.get_rental_price(period) * 9 / 10)
        else:
            return car.get_rental_price(period)


def is_wanted(car, brand, max_price):
        if brand is not None:
            if max_price is not None:
                if car.brand == brand and car.daily_price <= max_price:
                    return True
            else:
                if car.brand == brand:
                    return True
        else:
            if max_price is not None:
                if car.daily_price <= max_price:
                    return True
            else:
                return True
        return False

"""
Ex. 6
Definiti clasa Point ce primeste doua coordonate (x, y) are metode interne
pentru operatii aritmetice, definiti aceste metode astfel incat sa putem
aduna/scadea doua puncte. Sugestie __add__, __sub__.

Exemplu:
    p1 = Point(1, 2)
    p2 = Point(2, 3)
    p3 = p1 + p2
    p4 = p1 - p2
"""


class Point(object):
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __add__(self, p):
        new_x = self.x + p.x
        new_y = self.y + p.y
        return Point(new_x, new_y)

    def __sub__(self, p):
        new_x = self.x - p.x
        new_y = self.y - p.y
        return Point(new_x, new_y)

# Functia ajutatoare folosita la testare.
def test(got, expected):
    if got == expected:
        prefix = ' OK '
    else:
        prefix = '  X '
    print '{0} got: {1}, expected: {2}'.format(prefix, got, expected)


# Functia care testeaza rezultatele.
def main():
    from datetime import date, timedelta
    print "\nTeste pentru clasa DateRange"
    start = date(2012, 6, 24)
    end = date(2014, 1, 1)
    dr = DateRange(start, end)

    test(dr.contains(date(2012, 6, 24)), True)
    test(dr.contains(date(2014, 1, 1)), True)
    test(dr.contains(date(2013, 6, 24)), True)
    test(dr.contains(date(2014, 6, 24)), False)
    test(dr.days, 556)

    print "\nTeste pentru clasa Car"
    c = Car('Volvo', 'S60', 500)
    dr = DateRange(date.today(), date.today() + timedelta(days=7))
    test(c.get_rental_price(dr), 3500)
    test(str(c), "Acesta este un Volvo S60 si pretul la inchiriere este 500")

    print "\nTeste pentru clasa Limousine"
    l = Limousine('Mercedes', 'Diplomat Edition', 1200, 800)
    dr = DateRange(date.today(), date.today() + timedelta(days=3))
    test(l.get_rental_price(dr), 4400)

    print "\nTeste pentru clasa CarRental"
    c2 = Car('Mercedes', 'C-Class', 700)
    cr = CarRental()
    cr.add_car(c)
    cr.add_car(l)
    cr.add_car(c2)

    test(cr.get_cars(), [c, l, c2])
    test(cr.get_cars('Mercedes'), [l, c2])
    test(cr.get_cars('Mercedes', 700), [c2])
    test(cr.get_cars(max_price=600), [c])
    test(cr.get_cars(max_price=400), [])

    p = Person('Jane', 'Geller', date(1992, 12, 5))
    p2 = Person('John', 'Stain', date(1990, 12, 15))
    dr = DateRange(date(2015, 12, 1), date(2015, 12, 10))
    test(cr.get_price(p, c, dr), 4050)
    test(cr.get_price(p2, c2, dr), 6300)

    print "\nTeste pentru clasa Point"
    p1 = Point(1, 2)
    p2 = Point(3, 3)

    p3 = p1 + p2
    test(p3.x, p1.x + p2.x)
    test(p3.y, p1.y + p2.y)

    p3 = p1 - p2
    test(p3.x, p1.x - p2.x)
    test(p3.y, p1.y - p2.y)


if __name__ == '__main__':
    main()