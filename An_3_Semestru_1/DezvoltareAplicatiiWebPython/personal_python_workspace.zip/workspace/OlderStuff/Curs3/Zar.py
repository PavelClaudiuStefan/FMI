import random

class Zar:
    """Returns a number between 1 and 6"""
    
    def roll(self):
        return random.randint(1, 6)

class ZarNecinstit(Zar):
    """Always returns 5"""
    
    def roll(self):
        return 5