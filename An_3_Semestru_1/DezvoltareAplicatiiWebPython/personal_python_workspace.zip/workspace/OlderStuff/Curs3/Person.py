class Person():
    
    def __init__(self, name, account, salary=0):
        self.name = name
        self.account = account
        self.__salary = salary
    
    def set_salary(self, salary):
        self.__salary = salary
    
    def receive_salary(self):
        self.account.deposit(self.__salary)
    
    @property    
    def salary(self):
        return 'Confidential'
    
    def make_shopping(self, amount):
        print('You are buying useless stuff')
        self.account.draw(amount)
    
    def __str__(self):
        return (self.name + ' has the salary: ' + str(self.__salary) + ' and the account: ' + self.account.name)