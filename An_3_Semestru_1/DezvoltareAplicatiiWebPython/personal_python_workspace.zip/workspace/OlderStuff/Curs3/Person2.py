class Person():
    """Persoana does person stuff"""
    
    def __init__(self, name, age):
        self.name = name
        self.age = age
    
    def __str__(self):
        return self.name + ' ' + str(self.age)

def person_factory(list):
    return [Person(name, age) for (name, age) in list]
    
def sort_age(persons):
    ages = []
    for p in persons:
        if p.name[-4:] == 'escu':
            ages.append(p.age)
    return sorted(ages)


persons = person_factory([('Claudiu', 21), ('Alex', 17), ('Alin', 15), ('Popescu', 5), ('Georgescu', 2), ('Enescu', 52)])
ages = sort_age(persons)
print(ages)