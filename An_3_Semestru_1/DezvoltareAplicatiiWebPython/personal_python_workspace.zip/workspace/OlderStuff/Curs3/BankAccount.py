class BankAccount(object):
    def __init__(self, name, money):
        self.name = name
        self.money = money
    
    def deposit(self, amount):
        self.money += amount
        print('You deposited {}. You now have {} in {}.'.format(amount, self.money, self.name))
        
    def draw(self, amount):
        if amount < self.money:
            self.money -= amount
            print('You drew {}. You now have {} in {}.'.format(amount, self.money, self.name))
        else:
            print('Not enough funds. You only have {} in {}'.format(self.money, self.name))
    
    def __str__(self):
        return 'You have ' + str(self.money) + ' RON in ' + self.name


class SpecialBankAccount(BankAccount):
    def __init__(self, name, money, overdraft):
        super(SpecialBankAccount, self).__init__(name, money)
        self.overdraft = overdraft
    
    def draw(self, amount):
        if amount < (self.money + self.overdraft):
            self.money -= amount
            print('You drew {}. You now have {} in {}.'.format(amount, self.money, self.name))
        else:
            print('Creditul maxim a fost atins. You only have {} in {}'.format(self.money, self.name))