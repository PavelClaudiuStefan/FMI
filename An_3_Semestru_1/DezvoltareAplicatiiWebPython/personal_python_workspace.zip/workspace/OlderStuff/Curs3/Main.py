from BankAccount import BankAccount
from BankAccount import SpecialBankAccount
from Person import Person
from Zar import Zar
from Zar import ZarNecinstit

account = SpecialBankAccount('ING', 100, 100)
print(account)
account.deposit(10)
account.draw(120)
account.draw(100)

pers = Person('Claudiu', account, 1000)
pers.receive_salary()
print pers.salary
pers.make_shopping(995)

zar = Zar()
zar_necinstit = ZarNecinstit()

print([zar.roll() if zar.roll()%2==0 else zar_necinstit.roll() for i in xrange(0, 5)])
