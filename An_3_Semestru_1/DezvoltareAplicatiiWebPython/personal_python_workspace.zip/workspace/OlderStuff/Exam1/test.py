# Pavel Claudiu Stefan
# Grupa 333
# Nr II


# Ex 1
from datetime import datetime, date

def calculate_age(birthdate):
    today = date.today()
    return today.year - birthdate.year - ((today.month, today.day) < (birthdate.month, birthdate.day))

def ex1(lista):
    with open('age.txt', 'w') as output:
        for d in lista:
            name = d.get('name')
            birthdate = datetime.strptime(d.get('birthday'), '%d-%m-%Y')
            age = calculate_age(birthdate)
            output.write("{}, {}\n".format(name, age))


# Ex 2
def has_small_letters(word):
    for ch in word:
        if ch.islower():
            return True
    return False

def has_big_letters(word):
    for ch in word:
        if ch.isupper():
            return True
    return False

def ex2(words):
    return [word for word in words if has_small_letters(word) and has_big_letters(word)]


# Ex 3
def ex3():
    return {name: amount/20 for (name, amount) in students if amount > 0}


# Ex 4
class FidelityCard(object):
    def __init__(self, first_name, last_name):
        self.first_name = first_name
        self.last_name = last_name
        self._points = 0
    
    def buy(self, amount):
        self._points += int(amount * 0.01)
    
    def use_points(self, points):
        if points <= self._points:
            self._points -= points
        else:
            return None
    
    @property    
    def points(self):
        return 'Aveti {} puncte'.format(self._points)


#Ex 5
class GoldFidelityCard(FidelityCard):
    def __init__(self, first_name, last_name, bonus):
        super(GoldFidelityCard, self).__init__(first_name, last_name)
        self.bonus = bonus
    
    def buy(self, amount):
        self._points += int(amount * (0.01 + self.bonus))
    
    def use_points(self, points):
        if points <= self._points:
            self._points -= points
            self.bonus += 0.005
        else:
            return None




# Testing

print('Ex 1 - age.txt')
ex1([{'name' : 'Ana', 'birthday': "23-03-1988"},
     {'name' : 'Matei', 'birthday': "19-09-1999"},
     {'name' : 'Andreea', 'birthday': "03-12-1976"},
     {'name' : 'Catalin', 'birthday': "03-07-1960"}
     ])


print('\n\nEx 2:')
words = ['Mere', 'Madalina', 'castane', 'LUNA', 'LiLIac', 'randunica', 'ANA']
print(ex2(words))


print('\n\nEx 3:')
students = [('Ana', 60), ('Mihai', 80), ('Dana', 40), ('Madalina', 0), ('Ileana', 100)]
print ex3()


print('\n\nEx 4:')
my_fidelity_card = FidelityCard('Pavel', 'Claudiu')
my_fidelity_card.buy(1000)
print my_fidelity_card.points
my_fidelity_card.use_points(5)
print my_fidelity_card.points


print('\n\nEx 5:')
my_gold_fidelity_card = GoldFidelityCard('Pavel', 'Claudiu', 0.05)
my_gold_fidelity_card.buy(1000)
print my_gold_fidelity_card.points
my_gold_fidelity_card.use_points(60)
print my_gold_fidelity_card.points
my_gold_fidelity_card.buy(1000)
print my_gold_fidelity_card.points