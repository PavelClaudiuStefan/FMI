import json, requests

url = 'http://maps.googleapis.com/maps/api/directions/json'

params = dict(
    origin='Eau de Web',
    destination='Universitatea din Bucuresti',
)

resp = requests.get(url=url, params=params)

data = json.loads(resp.text)

for step in data['routes'][0]['legs'][0]['steps']:
    print "- " + step['html_instructions'] + "\n"
