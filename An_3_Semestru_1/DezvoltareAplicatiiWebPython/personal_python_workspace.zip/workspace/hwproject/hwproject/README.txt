    //Username - Password
        Claudiu - adminparola
        Pavel   - pavelparola