# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User


class Category(models.Model):
    name = models.CharField(max_length=200)
    description = models.CharField(max_length=10000)
    date_created = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.name


class Post(models.Model):
    text = models.CharField(max_length=10000)
    date_created = models.DateTimeField(auto_now_add=True)
    date_updated = models.DateTimeField(auto_now=True)
    
    user = models.ForeignKey(User)
    category = models.ForeignKey(Category)

    def __str__(self):
        return self.text


class Comment(models.Model):
    text = models.CharField(max_length=10000)
    date_created = models.DateTimeField(auto_now_add=True)
    date_updated = models.DateTimeField(auto_now=True)
    
    user = models.ForeignKey(User)
    post = models.ForeignKey(Post)
    comment = models.ForeignKey('self')

    def __str__(self):
        return self.text