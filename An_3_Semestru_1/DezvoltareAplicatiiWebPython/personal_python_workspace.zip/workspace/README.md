# Dezvoltare aplicatii web in python
# Pavel Claudiu Stefan
## Grupa 333

Cursuri : http://purepython.eaudeweb.ro/wiki/Home.html

JSON formatter : https://jsonformatter.curiousconcept.com/

User: claudiu
Password: adminparola

Util Django:
    //Create a new django project folder
        django-admin startproject project_name
    
    //Create a new in app in the project folder
        django-admin startapp app_name
    
    //Go in the project folder to be able to run manage.py
        cd project_name
    
    //Start server
        python manage.py runserver $IP:$PORT
    
    //Save changes
        python manage.py makemigrations
        ./manage.py migrate
    
    //Create an admin
        ./manage.py createsuperuser
    
    //Addmin settings
        website/admin
    
    //Username - Password
        Claudiu - adminparola
        Pavel  - pavelparola
        Stefan - stefanparola
        Andrei - andreiparola
        Alex   - alexparola

--------------------------------------------------------------------------------

Form
    .is_valid()     // Returneaza True/False
    .save()         // Opereaza modificari in DB
    
    
    duckmin
    secretduck