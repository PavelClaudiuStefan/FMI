f = @(x) x.^3-18.*x.^2-10;
interval=[-5 5];
eps = 10^(-3);

fplot(f,interval);
