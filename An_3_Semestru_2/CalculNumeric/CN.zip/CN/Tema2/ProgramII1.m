A = [0 1 2 ; 1 0 1; 3 2 1];
b = [8;4;10];
x = GaussPivTot(A,b);
x 
