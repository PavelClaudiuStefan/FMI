function [xaprox] = MetSecantei(f, a, b, x0, x1, eps)
    k = 1;
    
end

