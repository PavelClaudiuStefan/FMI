A = [4,2,2;2,10,4;2,4,6];

[x, L] = DescCholesky(A,b)